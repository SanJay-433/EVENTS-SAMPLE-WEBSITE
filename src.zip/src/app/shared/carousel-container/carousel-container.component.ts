import {
  Component,
  ViewChild,
  ElementRef,
  Input,
  AfterViewInit,
} from '@angular/core';

@Component({
  selector: 'app-carousel-container',
  templateUrl: './carousel-container.component.html',
  styleUrls: ['./carousel-container.component.css'],
})
export class CarouselContainerComponent implements AfterViewInit {
  @ViewChild('carouselScroll', { static: false })
  carouselScroll!: ElementRef<HTMLDivElement>;
  @Input() cardsPerSlide = 4;
  @Input() itemCount = 0;

  currentSlide = 0;

  ngAfterViewInit() {
    // Ensure scroll position is correct on init
    this.scrollToCurrent();
  }

  get totalSlides(): number {
    return Math.ceil(this.itemCount / this.cardsPerSlide);
  }

  get canPrev(): boolean {
    return this.currentSlide > 0;
  }

  get canNext(): boolean {
    return this.currentSlide < this.totalSlides - 1;
  }

  nextSlide() {
    if (this.canNext) {
      this.currentSlide++;
      this.scrollToCurrent();
    }
  }

  prevSlide() {
    if (this.canPrev) {
      this.currentSlide--;
      this.scrollToCurrent();
    }
  }

  scrollToCurrent() {
    if (this.carouselScroll) {
      // Support both .col-md-3 (products) and .col-md-12 (hero) or any card
      if(this.carouselScroll){
        this.carouselScroll.nativeElement.addEventListener('wheel',(event: WheelEvent)=>{
          if(event.deltaX !== 0){
            event.preventDefault();
          }
        });
      }
      const card =
        this.carouselScroll.nativeElement.querySelector('.col-md-3') ||
        this.carouselScroll.nativeElement.querySelector('.col-md-12');
      if (card) {
        const cardElem = card as HTMLElement;
        const cardStyle = getComputedStyle(cardElem);
        const cardWidth =
          cardElem.offsetWidth +
          parseInt(cardStyle.marginLeft) +
          parseInt(cardStyle.marginRight);
        const scrollLeft = this.currentSlide * cardWidth * this.cardsPerSlide;
        this.carouselScroll.nativeElement.scrollTo({
          left: scrollLeft,
          behavior: 'smooth',
        });
      }
    }
  }
}
