import { Component, Input , OnDestroy, OnInit } from '@angular/core';

@Component({
  selector: 'app-countdown-timer',
  templateUrl: './countdown-timer.component.html',
  styleUrls: ['./countdown-timer.component.css'],
})
export class CountdownTimerComponent implements OnInit, OnDestroy {
        @Input() targetDate!: Date;

  days:number = 0;
  hours:number = 0;
  minutes:number = 0;
  seconds:number = 0;

 timer:any;

  ngOnInit(): void{
          this.updateCountDown();
          this.timer = setInterval(() => this.updateCountDown(),1000);
  }

  ngOnDestroy(): void {
   clearInterval(this.timer);
  }

  updateCountDown(){
      const now = new Date().getTime();
      const distance = this.targetDate.getTime() - now;

      if(distance <= 0){
       this.days = this.hours = this.minutes = this.seconds = 0;
       clearInterval(this.timer);
       return;
      }
      
      this.days = Math.floor(distance / (1000 * 60 * 60 * 24));
      this.hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      this.minutes = Math.floor((distance % (1000 * 60 * 60 )) / (1000 * 60 ));
      this.seconds = Math.floor((distance % (1000 * 60 )) / 1000);
  }


}
