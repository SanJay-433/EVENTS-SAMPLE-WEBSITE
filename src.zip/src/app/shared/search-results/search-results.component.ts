import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Page } from 'src/app/models/page.model';
import { Product } from 'src/app/models/product.model';
import { ProductService } from 'src/app/service/product.service';

@Component({
  selector: 'app-search-results',
  templateUrl: './search-results.component.html',
  styleUrls: ['./search-results.component.css']
})
export class SearchResultsComponent implements OnInit {
  products: Product[] = [];
  errorMessage: string = '';
  searchQuery: string = '';
  totalPages: number = 0;
  currentPage: number = 0;
  selectedSort: string = 'default'; // 'default', 'price-asc', 'price-desc'
 
  constructor(
    private route: ActivatedRoute,
    private productService: ProductService
  ) {}
 
  ngOnInit(): void {
    this.route.queryParams.subscribe((params) => {
      this.searchQuery = params['q'] || '';
      this.currentPage = 0;
      this.selectedSort = 'default';
      if (this.searchQuery.trim()) {
        this.fetchProducts();
      } else {
        this.products = [];
        this.totalPages = 0;
      }
    });
  }
 
  onSortChange(): void {
    this.currentPage = 0;
    this.fetchProducts();
  }
 
  fetchProducts(page: number = 0): void {
    let sortBy = 'id';
    let sortOrder = 'asc';
 
    if (this.selectedSort === 'price-asc') {
      sortBy = 'price';
      sortOrder = 'asc';
    } else if (this.selectedSort === 'price-desc') {
      sortBy = 'price';
      sortOrder = 'desc';
    }
 
    this.productService
      .searchProducts(this.searchQuery, page, undefined, sortBy, sortOrder)
      .subscribe({
        next: (pagedData: Page<Product>) => {
          this.products = pagedData.content;
          this.totalPages = pagedData.totalPages;
          this.currentPage = pagedData.number || 0;
        },
        error: (error) => {
          this.errorMessage = 'Error fetching search results';
        },
      });
  }
 
  goToNextPage(): void {
    if (this.currentPage < this.totalPages - 1) {
      this.fetchProducts(this.currentPage + 1);
    }
  }
 
  goToPreviousPage(): void {
    if (this.currentPage > 0) {
      this.fetchProducts(this.currentPage - 1);
    }
  }
}
