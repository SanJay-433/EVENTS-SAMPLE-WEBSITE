export interface cartRequest{
    quantity : number;
    productId : number;
    userId : number;
}