export interface Product {
    id: number;
    name: string;
    description: string;
    price: number;
    category: string;
    brand?: string;
    imageUrl?: string;
    isAvailable?: boolean;
    stockQuantity: number; // <-- Add this line
  }