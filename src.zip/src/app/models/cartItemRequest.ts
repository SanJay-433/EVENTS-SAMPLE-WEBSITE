export interface cartItemRequest {
  userId: number;
  quantity: number;
}
