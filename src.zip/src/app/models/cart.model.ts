export interface CartItem {
  id: number; // cartItemId
  productId: number; // <-- Add this line
  name: string;
  image: string;
  price: number;
  quantity: number;
}
