export interface quotes{
    id: number,
    quote: string,
    author:string
}