export interface Page<T> {
    content: T[]; // The items of the current page
    totalElements: number; // Total number of items
    totalPages: number; // Total pages available
    size: number; // Items per page
    number: number; // Current page index (starts at 0)
  }