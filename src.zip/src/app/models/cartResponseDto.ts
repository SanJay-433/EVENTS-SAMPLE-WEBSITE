export interface cartResponse{
    cartItemId:number;
    quantity:number;
    totalPrice:number;
    productName:string;
    productPrice:number;
    productImage:string;
}