import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
 
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  standalone: false,
})
export class LoginComponent {
  loginObj: any = {
    userName: '',
    password: '',
  };
  errorMessage = '';
  showError = false;
 
  constructor(private http: HttpClient, private router: Router) {}
 
  ngOnInit(): void {
  }
 
  onLogin() {
    localStorage.removeItem('loginToken');
    this.http
      .post('http://localhost:3030/login', this.loginObj, {
        responseType: 'text',
      })
      .subscribe({
        next: (token: string) => {
          if (token) {
            alert('Login Success');
            console.log('Token:', token);
            localStorage.setItem('loginToken', token);
            this.router.navigateByUrl('/home');
          }
        },
        error: () => {
          this.errorMessage =
            'Wrong credentials. Please check your username and password.';
          this.showError = true;
        },
      });
  }
 
  navigateToRegister() {
    this.router.navigateByUrl('/register');
  }
 
  showPassword = false;
 
  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }
}