import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
 
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  standalone: false
})
export class RegisterComponent {
  registerObj: any = {
    userName: '',
    email: '',
    password: '',
    shippingAddress: '',
    paymentDetails: '',
    roles: 'USER',
  };
 
  showPassword = false;
 
  constructor(private http: HttpClient, private router: Router) {}
 
  ngOnInit(): void {
    localStorage.removeItem('loginToken');
  }
 
  onRegister() {
    this.http.post('http://localhost:3030/register', this.registerObj, { responseType: 'text' }).subscribe((response: string) => {
      if (response) {
        alert('Register Success');
        this.router.navigateByUrl('/login');
      } else {
        alert('Register Failed');
      }
    });
  }
 
  navigateToLogin() {
    this.router.navigateByUrl('/login');
  }
 
  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }
}