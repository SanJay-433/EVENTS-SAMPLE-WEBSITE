import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { HeaderComponent } from './component/header/header.component';
import { HomeComponent } from './component/home/home.component';
import { ShoppingComponent } from './component/shopping/shopping.component';
import { FooterComponent } from './component/footer/footer.component';
import { HeroComponent } from './component/hero/hero.component';
import { FeaturedCategoriesComponent } from './component/featured-categories/featured-categories.component';
import { BannerComponent } from './component/banner/banner.component';
import { CountdownTimerComponent } from './shared/countdown-timer/countdown-timer.component';
import { ProductCardComponent } from './component/product-card/product-card.component';
import { PopularProductsComponent } from './component/popular-products/popular-products.component';
import { CartComponent } from './component/cart/cart.component';
import { OrderCheckoutComponent } from './component/order-checkout/order-checkout.component';
import { ContactComponent } from './component/contact/contact.component';
import { RegisterComponent } from './authenticate/register/register.component';
import { LoginComponent } from './authenticate/login/login.component';
import { FormsModule } from '@angular/forms';
import {
  HTTP_INTERCEPTORS,
  HttpClient,
  HttpClientModule,
} from '@angular/common/http';
import { AuthService } from './service/authservice.interceptor';
import {
  NgbCarouselModule,
  NgbModule,
  NgbToastModule,
} from '@ng-bootstrap/ng-bootstrap';
import { NgTemplateOutlet } from '@angular/common';
import { ToastComponent } from './shared/toast/toast.component';
import { ComponentModule } from './component/component.module';
import { CarouselComponent } from './shared/carousel/carousel.component';
import { NgxSliderModule } from '@angular-slider/ngx-slider';
import { SearchBarComponent } from './shared/search-bar/search-bar.component';
import { SearchResultsComponent } from './shared/search-results/search-results.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    ShoppingComponent,
    FooterComponent,
    HeroComponent,
    FeaturedCategoriesComponent,
    BannerComponent,
    CountdownTimerComponent,
    ProductCardComponent,
    PopularProductsComponent,
    CartComponent,
    OrderCheckoutComponent,
    ContactComponent,
    RegisterComponent,
    LoginComponent,
    ToastComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    NgbModule,
    NgbToastModule,
    NgTemplateOutlet,
    ComponentModule,
    NgbCarouselModule,
    NgxSliderModule,
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AuthService, multi: true },
  ],
  schemas : [CUSTOM_ELEMENTS_SCHEMA],
  bootstrap: [AppComponent],
})
export class AppModule {}
