import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OrderserviceService {

 
  private apiUrl = 'http://localhost:3030/api/orders';
 
  constructor(private http: HttpClient) {}
 
  getUserId(): string | null {
    const token = localStorage.getItem('loginToken');
    if (token) {
      try {
        const decoded: any = JSON.parse(atob(token.split('.')[1]));
        console.log('Decoded token:', decoded.role[0]);
        return decoded.userId;
      } catch (error) {
        console.error('Error decoding token:', error);
        return null;
      }
    }
    return null;
  }
 
  placeOrder(address: string): Observable<any> {
    const userId = this.getUserId();
    if (!userId) throw new Error('User ID missing');
    return this.http.post(`${this.apiUrl}/${userId}/${address}`, {});
  }
 
  fetchOrdersByUser(): Observable<any[]> {
    const userId = this.getUserId();
    if (!userId) throw new Error('User ID missing');
    return this.http.get<any[]>(`${this.apiUrl}/${userId}`);
  }
}
