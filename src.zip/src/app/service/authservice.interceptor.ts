import { Injectable } from '@angular/core';
import {
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
} from '@angular/common/http';
 
@Injectable({
  providedIn: 'root',
})
export class AuthService implements HttpInterceptor {
  intercept(req: HttpRequest<any>, next: HttpHandler) {
    const token = localStorage.getItem('loginToken');
    console.log('Intercepting request to:', req.url);
    console.log('Retrieved token:', token);
 
    if (token) {
      // Decode the token and log userId
      const decoded: any = JSON.parse(atob(token.split('.')[1]));
      console.log('Extracted User ID:', decoded.userId);
 
      // Attach Authorization header to the request
      const clonedReq = req.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`,
        },
      });
      console.log('Authorization header added:', clonedReq.headers.get('Authorization'));
      return next.handle(clonedReq);
    }
 
    console.log('No token found, sending request without Authorization header');
    return next.handle(req);
  }
}