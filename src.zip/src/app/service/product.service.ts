import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from '../models/product.model';
import { Page } from '../models/page.model';

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  private baseUrl = 'http://localhost:3030/products';

  constructor(private http: HttpClient) {}

  // Helper to build pagination params.
  private createPaginationParams(
    page: number = 0,
    size: number = 8,
    sortBy: string = 'price',
    sortOrder: string = 'id'
  ): HttpParams {
    return new HttpParams()
      .set('page', page.toString())
      .set('size', size.toString())
      .set('sortBy', sortBy)
      .set('sortOrder', sortOrder);
  }

  // 1. Search products by name with pagination.
  searchProducts(
    name: string,
    page?: number,
    size?: number,
    sortBy?: string,
    sortOrder?: string
  ): Observable<Page<Product>> {
    let params = this.createPaginationParams(page, size, sortBy, sortOrder).set(
      'name',
      name
    );
    return this.http.get<Page<Product>>(`${this.baseUrl}/search`, { params });
  }

  // 2. Get products by category (with pagination)
  getProductsByCategory(
    category: string,
    page?: number,
    size?: number,
    sortBy?: string,
    sortOrder?: string
  ): Observable<Page<Product>> {
    let params = this.createPaginationParams(page, size, sortBy, sortOrder).set(
      'category',
      category
    );
    return this.http.get<Page<Product>>(`${this.baseUrl}/category`, { params });
  }

  // 3. Get products by brand (with pagination)
  getProductsByBrand(
    brand: string,
    page?: number,
    size?: number,
    sortBy?: string,
    sortOrder?: string
  ): Observable<Page<Product>> {
    let params = this.createPaginationParams(page, size, sortBy, sortOrder).set(
      'brand',
      brand
    );
    return this.http.get<Page<Product>>(`${this.baseUrl}/brand`, { params });
  }

  // 4. Get product by ID. (No pagination here)
  getProductById(id: number): Observable<Product> {
    return this.http.get<Product>(`${this.baseUrl}/${id}`);
  }

  // 5. Get categories. (Non-paginated)
  getCategories(): Observable<string[]> {
    return this.http.get<string[]>(`${this.baseUrl}/categories`);
  }

  getAllProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(`${this.baseUrl}/all`);
  }
  getProductsByPriceRange(min: number, max: number): Observable<Product[]> {
    const params = new HttpParams()
      .set('min', min.toString())
      .set('max', max.toString());
    return this.http.get<Product[]>(`${this.baseUrl}/price-range`, { params });
  }

  getProducts(){
    return this.http.get('https://dummyjson.com/quotes');
  }
}
