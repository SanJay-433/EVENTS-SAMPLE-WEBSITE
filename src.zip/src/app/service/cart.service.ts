import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { cartResponse } from '../models/cartResponseDto';
import { cartRequest } from '../models/cartRequestDto';
import { getUserIdFromToken } from '../utils/token-utils';
import { cartItemRequest } from '../models/cartItemRequest'
import { CartItem } from '../models/cart.model';
@Injectable({
  providedIn: 'root',
})
export class CartService {
  constructor(private http: HttpClient) {}
private cartItems: CartItem[] = [];
private cartItemsSubject = new BehaviorSubject<CartItem[]>([]);
  
addCartItem(cartRequest: cartRequest): Observable<cartResponse> {
    return this.http.post<cartResponse>(
      'http://localhost:3030/api/cart/add',
      cartRequest
    );
  }
 getCartItemsObservable(){
  return this.cartItemsSubject.asObservable();
 }
 setCartItems(items: CartItem[]){
  this.cartItems = items;
  this.cartItemsSubject.next(this.cartItems);
 }
 totalQuantity():number{
  return this.cartItems.reduce((total,items)=>total+items.quantity,0);
 }
  getCartItems(): Observable<any> {
    const userId = getUserIdFromToken();
    return this.http.get<any>(`http://localhost:3030/api/cart/user/${userId}`);
  }

  updateCartItem(
    cartItemId: number,
    cartRequest: cartItemRequest
  ): Observable<cartResponse> {
    const { userId, quantity } = cartRequest;
    return this.http.put<cartResponse>(
      `http://localhost:3030/api/cart/${cartItemId}`,
      { userId, quantity }
    );
  }

  removeCartItem(cartItemId: number): Observable<any> {
    const userId = getUserIdFromToken();
    return this.http.delete(
      `http://localhost:3030/api/cart/${cartItemId}/user/${userId}`
    );
  }

  getPosts() {
    return this.http.get('https://jsonplaceholder.typicode.com/posts');
  }
}
