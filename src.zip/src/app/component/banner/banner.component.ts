import { Component, OnDestroy, OnInit } from '@angular/core';

@Component({
  selector: 'app-banner',
  templateUrl: './banner.component.html',
  styleUrls: ['./banner.component.css']
})
export class BannerComponent {
         saleEndsAt : Date = new Date(new Date().getTime() + 3 * 24 * 60 * 60 * 1000)

         
}
