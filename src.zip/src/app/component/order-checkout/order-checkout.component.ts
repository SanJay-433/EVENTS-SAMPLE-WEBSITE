import { Component } from '@angular/core';
import { OrderserviceService } from 'src/app/service/orderservice.service';

@Component({
  selector: 'app-order-checkout',
  templateUrl: './order-checkout.component.html',
  styleUrls: ['./order-checkout.component.css']
})
export class OrderCheckoutComponent {
  address: string = '';
  orderData: any = null;
  isLoading = false;
  isOrderPlaced = false;
 
  constructor(private orderService: OrderserviceService) {}
 
  printReceipt() {
    const printContents = document.getElementById('receipt')?.innerHTML;
    const popup = window.open('', '_blank', 'width=800,height=600');
    if (popup && printContents) {
      popup.document.open();
      popup.document.write(`
        <html>
          <head>
            <title>Receipt</title>
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
          </head>
          <body onload="window.print(); window.close();">
            ${printContents}
          </body>
        </html>
      `);
      popup.document.close();
    }
  }
 
  placeOrder() {
    if (!this.address) {
      alert('Please enter a delivery address.');
      return;
    }
 
    this.isLoading = true;
 
    this.orderService.placeOrder(this.address).subscribe({
      next: (res) => {
        this.orderData = res;
        this.isOrderPlaced = true; // Set to true only on success
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Order placement failed:', err);
        alert('Failed to place order. Check for products in your cart.');
        this.isLoading = false;
        this.isOrderPlaced = false; // Ensure animation does not show on failure
      },
    });
  }
}
