import { Component } from '@angular/core';
import { OrderserviceService } from 'src/app/service/orderservice.service';

@Component({
  selector: 'app-orderhistory',
  templateUrl: './orderhistory.component.html',
  styleUrls: ['./orderhistory.component.css']
})
export class OrderhistoryComponent {
  orders: any[] = [];
  grandTotal = 0;
 
  constructor(private orderService: OrderserviceService) {}
 
  ngOnInit(): void {
    this.loadOrders();
  }
 
  loadOrders(): void {
    this.orderService.fetchOrdersByUser().subscribe({
      next: (data) => {
        this.orders = data;
        this.calculateGrandTotal();
      },
      error: (err) => {
        console.error('Failed to load order history:', err);
        alert('Unable to fetch order history.');
      }
    });
  }
 
  calculateGrandTotal(): void {
    this.grandTotal = this.orders.reduce((sum, order) => sum + order.totalPrice, 0);
  }
}
