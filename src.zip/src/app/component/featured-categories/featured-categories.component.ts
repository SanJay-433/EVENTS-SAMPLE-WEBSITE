import { Component } from '@angular/core';

@Component({
  selector: 'app-featured-categories',
  templateUrl: './featured-categories.component.html',
  styleUrls: ['./featured-categories.component.css'],
})
export class FeaturedCategoriesComponent {
  featuredItems = [
    { title: 'Latest from Sofa', image: 'assets/images/categories/sofa.png', showLink:true },
    { title: 'Latest from Chair', image: 'assets/images/categories/chair.png', showLink:true },
    { title: 'Latest from Table', image: 'assets/images/categories/armchair.png', showLink:true },
    { title: 'Latest from Bed', image: 'assets/images/categories/bed.png', showLink:true },
  ];
}
