import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { CartItem } from 'src/app/models/cart.model';
import { cartItemRequest } from 'src/app/models/cartItemRequest';
import { cartRequest } from 'src/app/models/cartRequestDto';
import { Product } from 'src/app/models/product.model';
import { CartService } from 'src/app/service/cart.service';
import { ProductService } from 'src/app/service/product.service';
import { ToastService } from 'src/app/service/toast.service';
import { getUserIdFromToken } from 'src/app/utils/token-utils';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent {
  cartItems: CartItem[] = [];

  product?: Product;
  errorMessage: string = '';
  private subscription?: Subscription;
  quantity: number = 1;
  isFavourite: boolean = false;
  isAdmin: boolean = false; // Added property to check admin role
  showUpdateForm: boolean = false; // Added property to toggle update form visibility
 
  constructor(
    private route: ActivatedRoute,
    private productService: ProductService,
    private http: HttpClient,
    private router: Router,
    private cartService: CartService,
    private toastService: ToastService
  ) {}
 
  ngOnInit(): void {
    const token = localStorage.getItem('loginToken');
    if (token) {
      const decoded: any = JSON.parse(atob(token.split('.')[1]));
      console.log('Decoded token:', decoded.role[0].authority);
      this.isAdmin = decoded.role[0]?.authority === 'ROLE_ADMIN'; // Check if the user is an admin
    }
 
    const idParam = this.route.snapshot.paramMap.get('id');
    if (idParam) {
      const id = Number(idParam);
      this.subscription = this.productService.getProductById(id).subscribe({
        next: (data) => {
          this.product = data;
          if (this.product && this.quantity > this.product.stockQuantity) {
            this.quantity = this.product.stockQuantity;
          }
        },
        error: (error) => {
          this.errorMessage = 'Error fetching product details';
          console.error(error);
        },
      });
    } else {
      this.errorMessage = 'Invalid product id';
    }
  }
 
  incrementQty() {
    if (this.product && this.quantity < this.product.stockQuantity) {
      this.quantity++;
    }
  }
 
  decrementQty() {
    if (this.quantity > 1) {
      this.quantity--;
    }
  }
 
  onQuantityInput(event: any) {
    const value = Number(event.target.value);
    if (this.product) {
      if (value < 1) {
        this.quantity = 1;
      } else if (value > this.product.stockQuantity) {
        this.quantity = this.product.stockQuantity;
      } else {
        this.quantity = value;
      }
    }
  }
 
  toggleFavourite() {
    this.isFavourite = !this.isFavourite;
  }
 
  deleteProduct() {
    if (this.product) {
      const token = localStorage.getItem('loginToken');
      if (token) {
        const headers = { Authorization: `Bearer ${token}` };
        this.http
          .delete(
            `http://localhost:3030/adminProduct/delete/${this.product.id}`,
            { headers }
          )
          .subscribe({
            next: () => {
              this.router.navigate(['/categories']); // Navigate to homepage or product list
            },
            error: (err) => {
              console.error('Error deleting product:', err);
              alert('Product deleted successfully!');
              this.router.navigate(['/categories']); // Navigate to homepage or product list
            },
          });
      } else {
        alert('You are not authorized to perform this action.');
      }
    }
  }
  openUpdateForm() {
    this.showUpdateForm = true;
  }
 
  closeUpdateForm() {
    this.showUpdateForm = false;
  }
 
  updateProduct() {
    if (this.product) {
      this.http
        .put(
          `http://localhost:3030/adminProduct/update/${this.product.id}`,
          this.product
        )
        .subscribe({
          next: () => {
            alert('Product updated successfully!');
            this.closeUpdateForm();
          },
          error: (err) => {
            console.error('Error updating product:', err);
            alert('Failed to update product.');
          },
        });
    }
  }
 
  ngOnDestroy(): void {
    this.subscription?.unsubscribe();
  }
  
  addToCart(){
    const userId = getUserIdFromToken();
    if(!userId){
      this.toastService.show({
        template:'User Not Logged In',
        classname: 'txt-danger bg-light',
        delay: 2000,
      })
      console.error('User Not Logged In...');
      return ;
    }
    const productId = this.product?.id;
    if (productId === undefined) {
      this.toastService.show({
        template: 'Product Does not Exist',
        classname: 'bg-danger text-light',
        delay: 2000,
      })
      console.error('Product ID is undefined.');
      return;
    }
    const cartRequest: cartRequest = {
      userId: userId,
      productId: productId,
      quantity: 1,
    };

    this.cartService.addCartItem(cartRequest).subscribe({
      next:(response) =>{
          this.toastService.show({
            template: 'Added To Cart',
            classname: 'bg-success text-light',
            delay:2000,
          });
          console.log('Added to Cart',response);
      }
    });
  }

  

}
