import { Component } from '@angular/core';
import { CartService } from 'src/app/service/cart.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
      totalQuantity=0;
      constructor(private cartService :CartService){}

      ngOnInit(){
        this.cartService.getCartItemsObservable().subscribe((cartItems)=>{
          this.totalQuantity = this.cartService.totalQuantity();
        });
      }
}
