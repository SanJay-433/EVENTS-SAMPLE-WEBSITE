import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css'],
})
export class AddProductComponent {
  product: any = {
    name: '',
    description: '',
    price: null,
    stockQuantity: null,
    category: '',
    brand: '',
    imageUrl: '',
    isAvailable: true,
  };

  constructor(private http: HttpClient, private router: Router) {}

  onAddProduct() {
    this.http
      .post('http://localhost:3030/adminProduct/add', this.product)
      .subscribe({
        next: (response) => {
          alert('Product added successfully!');
          this.resetForm();
          this.router.navigateByUrl('/shopping');
        },
        error: (err) => {
          console.error('Error adding product:', err);
          alert('Failed to add product. Please try again.');
        },
      });
  }

  resetForm() {
    this.product = {
      name: '',
      description: '',
      price: null,
      stockQuantity: null,
      category: '',
      brand: '',
      imageUrl: '',
      isAvailable: true,
    }; 
  }
}
