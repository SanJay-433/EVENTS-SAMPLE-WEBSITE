import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from 'src/app/service/product.service';
import { Product } from 'src/app/models/product.model';
import { Options } from '@angular-slider/ngx-slider';
import { getUserIdFromToken } from 'src/app/utils/token-utils';
import { ToastService } from 'src/app/service/toast.service';
import { CartService } from 'src/app/service/cart.service';
import { CartItem } from 'src/app/models/cart.model';
import { cartRequest } from 'src/app/models/cartRequestDto';

@Component({
  selector: 'app-shopping',
  templateUrl: './shopping.component.html',
  styleUrls: ['./shopping.component.css'],
})
export class ShoppingComponent implements OnInit {
  saleEndsAt: Date = new Date(new Date().getTime() + 2 * 24 * 60 * 60 * 1000);
    
  cartItems: CartItem[] = [];
  product?: Product;
  products: Product[] = [];
  categories: string[] = [];
  errorMessage = '';
  currentPage: number = 0;
  pageSize: number = 6;
  totalPages: number = 0;

  // Category dropdown
  selectedCategory: string = '';

  // Price range slider
  selectedMin: number = 0;
  selectedMax: number = 100000;
  sliderOptions: Options = {
    floor: 0,
    ceil: 100000,
    step: 100,
    translate: (value: number): string => `₹${value}`,
  };

  isAdmin: boolean = false; // Added property to check admin role
  username: string = ''; // Added property to store username

  constructor(
    private productService: ProductService,
    private router: Router,
    private route: ActivatedRoute,
    private toastService: ToastService,
    private cartService: CartService
  ) {}

  ngOnInit(): void {
    this.checkAdminRole(); // Check if the user is an admin
    this.fetchCategories();
    this.fetchProducts();
    this.fetchUsername(); // Fetch username from token
    this.route.queryParams.subscribe((params) => {
      const category = params['category'];
      console.log('Category from query params:', category); // Debugging

      if (category) {
        this.selectedCategory = category;
        this.fetchProductsByCategory(category);
      } else {
        this.fetchProducts();
      }
    });
  }

  checkAdminRole(): void {
    const token = localStorage.getItem('loginToken');
    if (token) {
      const decoded: any = JSON.parse(atob(token.split('.')[1]));

      this.isAdmin = decoded.role[0]?.authority === 'ROLE_ADMIN';
    }
  }

  fetchUsername(): void {
    const token = localStorage.getItem('loginToken');
    if (token) {
      const decoded: any = JSON.parse(atob(token.split('.')[1]));
      this.username = decoded.username || 'Guest'; // Extract username or default to 'Guest'
    }
  }

  fetchProducts(): void {
    if (this.selectedCategory) {
      this.fetchProductsByCategory(this.selectedCategory);
      return;
    }
    this.productService
      .searchProducts('', this.currentPage, this.pageSize)
      .subscribe({
        next: (pagedData) => {
          this.products = pagedData.content;
          this.totalPages = pagedData.totalPages;
        },
        error: (error) => {
          this.errorMessage = 'Error fetching products';
        },
      });
  }

  fetchProductsByCategory(category: string): void {
    this.currentPage = 0;
    this.productService
      .getProductsByCategory(category, this.currentPage, this.pageSize)
      .subscribe({
        next: (pagedData) => {
          console.log('Fetched products:', pagedData.content); // Debugging
          this.products = pagedData.content;
          // filter(
          //   (product) => product.category === category
          // );// Filter products by selected category
          console.log('Products array:', this.products); // Debugging

          this.totalPages = pagedData.totalPages;
        },
        error: (error) => {
          this.errorMessage = 'Error fetching products by category';
        },
      });
  }

  fetchCategories(): void {
    this.productService.getCategories().subscribe({
      next: (data) => {
        this.categories = data;
      },
      error: (error) => {
        this.errorMessage = 'Error fetching categories';
      },
    });
  }

  goToNextPage(): void {
    if (this.currentPage < this.totalPages - 1) {
      this.currentPage++;
      this.fetchProducts();
    }
  }

  goToPreviousPage(): void {
    if (this.currentPage > 0) {
      this.currentPage--;
      this.fetchProducts();
    }
  }

  onCategoryChange(): void {
    this.currentPage = 0;
    if (this.selectedCategory) {
      this.fetchProductsByCategory(this.selectedCategory);
    } else {
      this.fetchProducts();
    }
  }

  onPriceRangeFilter(): void {
    this.selectedCategory = ''; // Set dropdown to "All"
    this.currentPage = 0;
    this.productService
      .getProductsByPriceRange(this.selectedMin, this.selectedMax)
      .subscribe({
        next: (products) => {
          this.products = products;
          this.totalPages = 1;
          this.currentPage = 0;
        },
        error: (error) => {
          this.errorMessage = 'Error fetching products by price range';
        },
      });
  }

  navigateToAddProduct(): void {
    this.router.navigate(['/add-product']); // Navigate to the add-product route
  }

  addToCart(productId: number): void {
    const userId = getUserIdFromToken();
    if(!userId){
      console.log('User not logged In...');
      this.toastService.show({
        template: 'User not logged in',
        classname: 'bg-danger txt-light',
        delay: 2000
      });
      return;
    }
    if (productId === undefined) {
      this.toastService.show({
        template: 'Product Does not Exist',
        classname: 'bg-danger text-light',
        delay: 2000,
      })
      console.error('Product ID is undefined.');
      return;
    }
    const cartRequest:cartRequest = {
      userId : userId,
      productId : productId,
      quantity : 1
    }
    this.cartService.addCartItem(cartRequest).subscribe({
      next :(response) =>{
        this.toastService.show({
          template: 'Added To Cart',
          classname: 'bg-success text-light',
          delay:2000,
        });
        console.log('Added to Cart',response);
      },
    })
  }
}
