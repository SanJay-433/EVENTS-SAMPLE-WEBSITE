import { Component, Input } from '@angular/core';
import { cartRequest } from 'src/app/models/cartRequestDto';
import { Product } from 'src/app/models/product.model';
import { CartService } from 'src/app/service/cart.service';
import { ToastService } from 'src/app/service/toast.service';
import { getUserIdFromToken } from 'src/app/utils/token-utils';

@Component({
  selector: 'app-product-card',
  templateUrl: './product-card.component.html',
  styleUrls: ['./product-card.component.css'],
})
export class ProductCardComponent {
  // @Input() product!: Product;
  // constructor(
  //   private cartService: CartService,
  //   private toastService: ToastService
  // ) {}

  // //Add to Cart
  // addToCart() {
  //   const userId = getUserIdFromToken();
  //   if (!userId) {
  //     // Optionally show a message or redirect to login
  //     console.error('User not logged in');
  //     return;
  //   }
  //   const productId = this.product.productId;
  //   const cartRequest: cartRequest = {
  //     userId: userId,
  //     productId: productId,
  //     quantity: 1,
  //   };
  //   this.cartService.addCartItem(cartRequest).subscribe({
  //     next: (response) => {
  //       this.toastService.show({
  //         template: `Added to Cart`,
  //         classname: 'bg-success text-light',
  //         delay: 1000,
  //       });
  //       console.log('Added to Cart', response);
  //     },
  //   });
  // }
}
