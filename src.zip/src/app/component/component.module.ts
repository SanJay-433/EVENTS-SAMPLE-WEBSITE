import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PageBannerComponent } from '../shared/page-banner/page-banner.component';
import { CarouselContainerComponent } from '../shared/carousel-container/carousel-container.component';
import { CarouselComponent } from '../shared/carousel/carousel.component';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from '../app-routing.module';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { SearchBarComponent } from '../shared/search-bar/search-bar.component';
import { SearchResultsComponent } from '../shared/search-results/search-results.component';
import { OrderhistoryComponent } from './orderhistory/orderhistory.component';
import { AddProductComponent } from './add-product/add-product.component';

@NgModule({
  declarations: [
    PageBannerComponent,
    CarouselContainerComponent,
    CarouselComponent,
    ProductDetailsComponent,
    SearchBarComponent,
    SearchResultsComponent,
    OrderhistoryComponent,
    AddProductComponent
  ],
  imports: [CommonModule, FormsModule, NgbModule, AppRoutingModule],
  exports: [PageBannerComponent, CarouselContainerComponent, CarouselComponent,SearchBarComponent,SearchResultsComponent]
})
export class ComponentModule {}
