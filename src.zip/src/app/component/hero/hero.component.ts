import { Component } from '@angular/core';
import { jwtDecode } from 'jwt-decode';
interface JwtPayload {
  exp: number;
  username: string;
}
@Component({
  selector: 'app-hero',
  templateUrl: './hero.component.html',
  styleUrls: ['./hero.component.css'],
})
export class HeroComponent {
  userName!: string;
  ngOnInit() {
    const token = localStorage.getItem('loginToken');
    if (token) {
      console.log(jwtDecode<JwtPayload>(token).username);
      this.userName = jwtDecode<JwtPayload>(token).username;
    }
  }
  heroSlides = [
    {
      title: 'Wood &<br>Cloth Sofa',
      description:
        'Shop Premium, feel premium.Explore our curated selection of designer furniture.',
      buttonText: 'Shop Now',
      buttonLink: '/shopping',
      imageUrl: 'assets/images/hero-furniture.png.jpg',
      welcomeText: `Hi, ${this.userName}`,
    },
    {
      title: 'Modern Living',
      description: 'Upgrade your space with our modern furniture collection.',
      buttonText: 'Explore',
      buttonLink: '/shopping',
      imageUrl: 'https://images.unsplash.com/photo-1618351708125-f8d1035c1b15?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    },
    {
      title: 'Wood &<br>Cloth Sofa',
      description:
        'Shop Premium, feel premium.Explore our curated selection of designer furniture.',
      buttonText: 'Shop Now',
      buttonLink: '/shopping',
      imageUrl: 'assets/images/hero-furniture.png.jpg',
      welcomeText: `Hi, ${this.userName}`,
    }
  ];
}
