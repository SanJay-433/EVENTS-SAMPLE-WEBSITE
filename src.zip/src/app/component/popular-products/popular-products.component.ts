import { Component } from '@angular/core';
import { Product } from 'src/app/models/product.model';

@Component({
  selector: 'app-popular-products',
  templateUrl: './popular-products.component.html',
  styleUrls: ['./popular-products.component.css'],
})
export class PopularProductsComponent {
  // products: Product[] = [
  //   {
  //     productId:1,
  //     title: 'Comfy',
  //     imageUrl: 'assets/images/categories/chair.png',
  //     price: 120,
  //   },
  //   {
  //     productId:2,
  //     title: 'Chair',
  //     imageUrl: 'assets/images/categories/armchair.png',
  //     price: 120,
  //   },

  //   {
  //     productId:3,
  //     title: 'Chair',
  //     imageUrl: 'assets/images/categories/chair1.jpg',
  //     price: 120,
  //   },

  //   {
  //     productId:4,
  //     title: 'Chair',
  //     imageUrl: 'assets/images/categories/armchair.png',
  //     price: 120,
  //   },

  //   {
  //     productId:5,
  //     title: 'Chair',
  //     imageUrl: 'assets/images/categories/chair1.jpg',
  //     price: 120,
  //   },

  //   {
  //     productId:6,
  //     title: 'Chair',
  //     imageUrl: 'assets/images/categories/chair.png',
  //     price: 120,
  //   },

  //   {
  //     productId:7,
  //     title: 'Chair',
  //     imageUrl: 'assets/images/categories/chair1.jpg',
  //     price: 120,
  //   },
  // ];
}
