import { Component, OnInit } from '@angular/core';
import { CartService } from 'src/app/service/cart.service';
import { cartResponse } from 'src/app/models/cartResponseDto';
import { CartItem } from 'src/app/models/cart.model';
import { getUserIdFromToken } from 'src/app/utils/token-utils';
import { cartItemRequest } from 'src/app/models/cartItemRequest';
import { ProductService } from 'src/app/service/product.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
})
export class CartComponent implements OnInit {
  cartItems: CartItem[] = [];

  constructor(private cartService: CartService) {}

  ngOnInit() {
    this.getCart();
  }

  getCart() {
    this.cartService.getCartItems().subscribe({
      next: (summary: any) => {
        let cartArray = summary.cartItems || [];
        this.cartItems = cartArray.map((item: any) => ({
          id: item.cartItemId,
          productId: item.productId,
          name: item.productName,
          image: item.productImage, 
          price: item.productPrice,
          quantity: item.quantity,
        }));
        this.cartService.setCartItems(this.cartItems);
      },
      error: (err) => {
        console.error('Failed to fetch cart items', err);
      },
    });
  }

  get subtotal(): number {
    return this.cartItems.reduce(
      (sum, item) => sum + item.price * item.quantity,
      0
    );
  }
  get totalQuantity(): number {
    return this.cartItems.reduce((total, item) => total + item.quantity, 0);
  }
  updateQuantity(item: CartItem, change: number) {
    const newQty = item.quantity + change;
    const userId = getUserIdFromToken();
    if (userId === null) {
      console.error('User not logged in');
      return;
    }
    if (newQty > 0) {
      const cartItemRequest: cartItemRequest = {
        userId: userId,
        quantity: newQty,
      };
      this.cartService.updateCartItem(item.id, cartItemRequest).subscribe({
        next: () => {
          this.getCart(); // Refresh cart from backend after update
        },
        error: (err) => {
          console.error('Failed to update quantity', err);
        },
      });
    } else if (newQty === 0) {
      this.removeItem(item);
    }
  }

  removeItem(item: CartItem) {
    // Optimistically remove from UI
    this.cartItems = this.cartItems.filter((i) => i.id !== item.id);
    this.cartService.removeCartItem(item.id).subscribe({
      next: () => {        this.getCart(); // Ensure sync with backend
      },
      error: (err) => {
        console.error('Failed to remove item', err);
        this.getCart(); // Re-sync in case of error
      },
    });
  }
}
