import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './component/home/home.component';
import { ShoppingComponent } from './component/shopping/shopping.component';
import { CartComponent } from './component/cart/cart.component';
import { OrderCheckoutComponent } from './component/order-checkout/order-checkout.component';
import { ContactComponent } from './component/contact/contact.component';
import { LoginComponent } from './authenticate/login/login.component';
import { RegisterComponent } from './authenticate/register/register.component';
import { ProductDetailsComponent } from './component/product-details/product-details.component';
import { SearchResultsComponent } from './shared/search-results/search-results.component';
import { OrderhistoryComponent } from './component/orderhistory/orderhistory.component';
import { AddProductComponent } from './component/add-product/add-product.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'shopping', component: ShoppingComponent },
  { path: 'cart' , component: CartComponent },
  { path: 'checkout' , component: OrderCheckoutComponent },
  { path: 'contact' , component: ContactComponent },
  { path:  '' , redirectTo:'login' , pathMatch: 'full'},
  { path: 'login' , component: LoginComponent},
  { path : 'register' , component: RegisterComponent},
  { path : 'product/:id' , component: ProductDetailsComponent},
  { path : 'search' , component: SearchResultsComponent},
  { path : 'checkoutHistory', component: OrderhistoryComponent},
  { path : 'add-product', component: AddProductComponent}
];

@NgModule({
  declarations: [],
  imports: [CommonModule, RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
