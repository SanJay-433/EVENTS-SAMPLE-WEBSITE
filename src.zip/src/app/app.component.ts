import { Component } from '@angular/core';
import { FooterComponent } from './component/footer/footer.component';
import { getUserIdFromToken } from './utils/token-utils';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],

})
export class AppComponent {
  title = 'ecommerce-frontend';
  constructor() {
    console.log('AppComponent initialized');
  }
  ngOnInit() {
    console.log('AppComponent ngOnInit called');
    if(getUserIdFromToken()) {
      console.log('User is logged in with ID:', getUserIdFromToken());
    }
    else {
      console.error('User is not logged in');
    }
  }
}
